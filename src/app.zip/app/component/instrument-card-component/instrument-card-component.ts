import { Component, Input } from '@angular/core';
import { FuturesContract } from '../../service/instrument-service';
import { InstrumentPriceComponent } from '../instrument-price-component/instrument-price-component';
import { InstrumentLevelsComponent } from "../instrument-levels-component/instrument-levels-component";
import { TradeRiskComponent } from '../trade-risk-component/trade-risk-component';

@Component({
  selector: 'app-instrument-card-component',
  imports: [InstrumentPriceComponent, InstrumentLevelsComponent, TradeRiskComponent],
  templateUrl: './instrument-card-component.html',
  styleUrl: './instrument-card-component.css',
})
export class InstrumentCardComponent {
  @Input() contract!: FuturesContract;
}
