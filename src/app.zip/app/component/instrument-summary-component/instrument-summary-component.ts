import { Component } from '@angular/core';

@Component({
  selector: 'app-instrument-summary-component',
  imports: [],
  templateUrl: './instrument-summary-component.html',
  styleUrl: './instrument-summary-component.css',
})
export class InstrumentSummaryComponent {

}
