import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { CategorySelectorComponent } from '../category-selector-component/category-selector-component';
import { CategoryService } from '../../service/category-service';
import { InstrumentCardComponent } from '../instrument-card-component/instrument-card-component';
import { FuturesContract, InstrumentService } from '../../service/instrument-service';

@Component({
  selector: 'app-home-component',
  imports: [CategorySelectorComponent, InstrumentCardComponent],
  templateUrl: './home-component.html',
  styleUrl: './home-component.css',
})
export class HomeComponent implements OnInit, OnDestroy {
  categoryNames: string[] = [];
  visibleInstruments: FuturesContract[] = [];

  private categorySub!: Subscription;

  constructor(
    private categoryService: CategoryService,
    private instrumentService: InstrumentService
  ) {}

  ngOnInit(): void {
    this.categoryNames = this.categoryService.categories;
    this.categoryNames.forEach((name) => this.categoryService.toggle(name));

    this.categorySub = this.categoryService.selectedCategories$.subscribe(
      (selected) => (this.visibleInstruments = this.instrumentService.getByCategories(selected))
    );
  }

  ngOnDestroy(): void {
    this.categorySub.unsubscribe();
  }
}
